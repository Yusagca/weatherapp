import { useState,useEffect } from 'react'
import './App.css'
import Days from './components/Days'
import { CiLocationArrow1 } from "react-icons/ci";
import { TbLocationFilled } from "react-icons/tb";
import { FaSearchLocation } from "react-icons/fa";
import { render } from 'react-dom';

//ist konum api = https://api.open-meteo.com/v1/forecast?latitude=41.0138&longitude=28.9497&current=temperature_2m&hourly=temperature_2m&timezone=Europe%2FBerlin&forecast_days=3



function App() {
  
  const[latitude,setLatitude] = useState("41.01384")
  const[longitude,setLongitude] = useState("28.9497")
  const [temperature,setTemperature] = useState()
  const [city,setCity] = useState()
  const[cityName , setCityName] = useState()
  const [message, setMessage] = useState('');
  const [api,setApi] = useState("https://api.open-meteo.com/v1/forecast?latitude="+latitude+"&longitude="+longitude+"&current=temperature_2m,wind_speed_10m")

  const handleMessageChange = event => {
    setMessage(event.target.value);
  };
  //`https://api.open-meteo.com/v1/forecast?latitude=${city.results[0].latitude}&longitude=${city.results[0].longitude}&current=temperature_2m,wind_speed_10m`
    useEffect(()=>{
    fetch(api)
    .then(res =>{
        return res.json()
    })
    .then(data=>setTemperature(data))
    console.log("useEffect api-> ",api)
    


  },[city])

  useEffect(()=>{
    fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${cityName}&count=1&language=en&format=json`)
    .then(rese =>{
        return rese.json()
    })
    .then(city=>setCity(city))
  },[cityName])

  if (cityName==undefined) {
    setCityName("istanbul")
    
  }
  


  function cityChange(data) {
      setCityName(data)
      setLatitude(city.results[0].latitude)
      setLongitude(city.results[0].longitude)
      setApi("https://api.open-meteo.com/v1/forecast?latitude="+latitude+"&longitude="+longitude+"&current=temperature_2m,wind_speed_10m")

  }

 
  console.log("city:",city)
  console.log("temp:",temperature)
  console.log("cityName:",cityName)

  
  return (
    
    <>
    {temperature&&city&&cityName&& city.results[0] ? (<div className='h-full w-full bg-sky-400 flex items-center justify-center p-11'>
      <div className='h-[670px] w-[490px] bg-gradient-to-t from-white to-orange-300 border-4 border-white rounded-lg object-contain overflow-auto items-center p-2'>
        <div className='flex flex-row h-[40px] items-center justify-center'>
          <textarea value={message} onChange={handleMessageChange} id='cityData' className='resize-none w-[400px] h-[40px] outline-none rounded-3xl text-center items-center text-orange-300 text-3xl'></textarea>
          <i className='ml-4' onClick={() => cityChange(message)}><FaSearchLocation className='text-white text-3xl text-center' /></i>
        </div>
        <div className='flex flex-row items-center'>
          <TbLocationFilled className='text-5xl text-white font-extrabold'></TbLocationFilled>
          <h1 className='font-bold text-6xl text-white p-3'>{city.results[0].name} </h1>
        </div>

        <div className='flex flex-col items-center justify-center'>
          <span className='p-4 text-5xl font-thin text-white mt-1'>Today {city.results[0].name} is</span>
          <span className=' text-6xl font-bold text-white'>{temperature.current.temperature_2m} C°</span>
        </div>
        <div className="w-full grid grid-cols-3 grid-rows-1 gap-6 p-6 items-center mt-5">
          <Days></Days>
        </div>


      </div>
    </div>):(
        <p>Veri yükleniyor</p>
      )}
    </>
  )
}

export default App
